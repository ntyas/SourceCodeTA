package com.example.aquaponics.api;

import com.example.aquaponics.get.GetDataSensor;

import retrofit2.Call;
import retrofit2.http.GET;

public interface RegisterAPIBacaSensor {
    String URL = "http://aquaponik.iotcenter.id/";
    @GET("Bacasensor.php")
    Call<GetDataSensor> getNilaiSensor();
}

package com.example.aquaponics.api;

import com.example.aquaponics.get.GetNilaiAwal;


import retrofit2.Call;
import retrofit2.http.GET;

public interface RegisterAPIBacaNilaiawal {
    String URL = "http://aquaponik.iotcenter.id/";
    @GET("Bacanilaiawal.php?")
    Call<GetNilaiAwal> getNilaiAwal();

}

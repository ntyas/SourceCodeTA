package com.example.aquaponics.get;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class GetNilaiAwal {

    @SerializedName("id_nilaiawal") @Expose String id;
    @SerializedName("ph_bawah") @Expose String ph_bawah;
    @SerializedName("ph_atas") @Expose String ph_atas;
    @SerializedName("ppm_bawah") @Expose String ppm_bawah;
    @SerializedName("ppm_atas") @Expose String ppm_atas;
    @SerializedName("suhu_bawah") @Expose String suhu_bawah;
    @SerializedName("suhu_atas") @Expose String suhu_atas;
    @SerializedName("intensitas_makan") @Expose String makan;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getMakan() {
        return makan;
    }

    public void setMakan(String makan) {
        this.makan = makan;
    }

    public String getPh_bawah() {
        return ph_bawah;
    }

    public void setPh_bawah(String ph_bawah) {
        this.ph_bawah = ph_bawah;
    }

    public String getPh_atas() {
        return ph_atas;
    }

    public void setPh_atas(String ph_atas) {
        this.ph_atas = ph_atas;
    }

    public String getPpm_bawah() {
        return ppm_bawah;
    }

    public void setPpm_bawah(String ppm_bawah) {
        this.ppm_bawah = ppm_bawah;
    }

    public String getPpm_atas() {
        return ppm_atas;
    }

    public void setPpm_atas(String ppm_atas) {
        this.ppm_atas = ppm_atas;
    }

    public String getSuhu_bawah() {
        return suhu_bawah;
    }

    public void setSuhu_bawah(String suhu_bawah) {
        this.suhu_bawah = suhu_bawah;
    }

    public String getSuhu_atas() {
        return suhu_atas;
    }

    public void setSuhu_atas(String suhu_atas) {
        this.suhu_atas = suhu_atas;
    }

}

package com.example.aquaponics.get;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

public class GetDataSensorPerJam {
    @SerializedName("id_akuaponik") @Expose String id_akuaponik;
    @SerializedName("ph_air") @Expose String ph_air;
    @SerializedName("ppm_air") @Expose String ppm_air;
    @SerializedName("suhu_air") @Expose String suhu_air;
    @SerializedName("aliran_air") @Expose String aliran_air;
    private ArrayList<String> data;

    public ArrayList<String> getData() {
        return data;
    }

    public void setData(ArrayList<String> data) {
        this.data = data;
    }

    public String getId_akuaponik() {
        return id_akuaponik;
    }

    public void setId_akuaponik(String id_akuaponik) {
        this.id_akuaponik = id_akuaponik;
    }

    public String getPh_air() {
        return ph_air;
    }

    public void setPh_air(String ph_air) {
        this.ph_air = ph_air;
    }

    public String getPpm_air() {
        return ppm_air;
    }

    public void setPpm_air(String ppm_air) {
        this.ppm_air = ppm_air;
    }

    public String getSuhu_air() {
        return suhu_air;
    }

    public void setSuhu_air(String suhu_air) {
        this.suhu_air = suhu_air;
    }

    public String getAliran_air() {
        return aliran_air;
    }

    public void setAliran_air(String aliran_air) {
        this.aliran_air = aliran_air;
    }
}

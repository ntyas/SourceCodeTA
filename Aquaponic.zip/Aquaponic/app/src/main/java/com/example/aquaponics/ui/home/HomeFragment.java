package com.example.aquaponics.ui.home;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.support.v4.app.NotificationCompat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.widget.Toast;

import com.example.aquaponics.R;
import com.example.aquaponics.api.RegisterAPIBacaNilaiawal;
import com.example.aquaponics.api.RegisterAPIBacaSensor;
import com.example.aquaponics.api.RegisterAPIBacaSensorPerJam;
import com.example.aquaponics.get.GetDataSensor;
import com.example.aquaponics.get.GetDataSensorPerJam;
import com.example.aquaponics.get.GetNilaiAwal;
import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.interfaces.datasets.ILineDataSet;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

import static android.content.Context.NOTIFICATION_SERVICE;

public class HomeFragment extends Fragment {

    TextView ph_bawah, ph_atas, ppm_bawah, ppm_atas, suhu_bawah, suhu_atas, nilaipH, nilaiPpm, nilaiSuhu,pompaAir, waktuMakan;
    String nilai_pH, nilai_Ppm, nilai_Suhu;
    String nilaiphbawah,nilaiphatas, nilaippmbawah, nilaippmatas, nilaisuhubawah, nilaisuhuatas, nilaimakan;
    String kondisi1, kondisi2, kondisi3;
    int  nilaiAliranAir;
    int kondisipH, kondisippm, kondisiSuhu;int n;
    int kondisi;
    LineChart chartpH, chartTds, chartSuhu;
    int[] dataPpm = new int[30];
    int[] dataSuhu = new int[30];
    float[] datapH = new float[30];
    Handler handler;

    public HomeFragment(){

    }
    @Override
    public View onCreateView(LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState)
    {
        return inflater.inflate(R.layout.fragment_home, container, false);
    }
    @Override
    public void onViewCreated(@NonNull final View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        ph_bawah = view.findViewById(R.id.pHBawah);
        ph_atas = view.findViewById(R.id.pHAtas);
        ppm_bawah = view.findViewById(R.id.ppmBawah);
        ppm_atas = view.findViewById(R.id.ppmAtas);
        suhu_bawah = view.findViewById(R.id.suhuBawah);
        suhu_atas = view.findViewById(R.id.suhuAtas);
        nilaipH = view.findViewById(R.id.nilaipH);
        nilaiPpm = view.findViewById(R.id.nilaippm);
        nilaiSuhu = view.findViewById(R.id.nilaiSuhu);
        pompaAir = view.findViewById(R.id.pompaiar);
        waktuMakan = view.findViewById(R.id.wktMundur);

        chartpH = view.findViewById(R.id.chartpH);
        chartTds = view.findViewById(R.id.chartTds);
        chartSuhu = view.findViewById(R.id.chartSuhu);

        chartpH.setDragEnabled(true);
        chartTds.setDragEnabled(true);
        chartSuhu.setDragEnabled(true);
        chartpH.setScaleEnabled(false);
        chartTds.setScaleEnabled(false);
        chartSuhu.setScaleEnabled(false);

        this.handler = new Handler();
        runnable.run();
//        handler = new Handler();
//        handler.postDelayed(new Runnable() {
//            @Override
//            public void run() {
//                TampilDataAwal();
//                TampilDataSensor();
//                TampilDataPerJam();
//                handler.postDelayed(this, 5000);
//            }
//        }, 1000);
    }
    private final Runnable runnable = new Runnable() {
        @Override
        public void run() {
            TampilDataAwal();
            TampilDataSensor();
            TampilDataPerJam();
            HomeFragment.this.handler.postDelayed(runnable, 5000);
        }
    };


    private void TampilDataAwal() {
        Retrofit retrofitBacaAwal = new Retrofit.Builder()
                .baseUrl(RegisterAPIBacaNilaiawal.URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        RegisterAPIBacaNilaiawal apiBacaNilaiawal = retrofitBacaAwal.create(RegisterAPIBacaNilaiawal.class);
        Call<GetNilaiAwal> callNilaiawal = apiBacaNilaiawal.getNilaiAwal();
        callNilaiawal.enqueue(new Callback<GetNilaiAwal>(){
            @Override
            public void onResponse(Call<GetNilaiAwal> call, Response<GetNilaiAwal> response) {
                if(response.isSuccessful()){
                    nilaiphbawah = response.body().getPh_bawah();
                    nilaiphatas = response.body().getPh_atas();
                    nilaippmbawah = response.body().getPpm_bawah();
                    nilaippmatas = response.body().getPpm_atas();
                    nilaisuhubawah = response.body().getSuhu_bawah();
                    nilaisuhuatas = response.body().getSuhu_atas();
                    nilaimakan = response.body().getMakan();
                    ph_bawah.setText(nilaiphbawah);
                    ph_atas.setText(nilaiphatas);
                    ppm_bawah.setText(nilaippmbawah);
                    ppm_atas.setText(nilaippmatas);
                    suhu_bawah.setText(nilaisuhubawah);
                    suhu_atas.setText(nilaisuhuatas);
                    waktuMakan.setText(nilaimakan);
                }
            }

            @Override
            public void onFailure(Call<GetNilaiAwal> call, Throwable t) {
                Toast.makeText(getContext(), "Periksa Koneksi Internet",Toast.LENGTH_LONG).show();

            }
        });
    }

    private void TampilDataPerJam() {
        Retrofit retrofitPerJam = new Retrofit.Builder()
                .baseUrl(RegisterAPIBacaSensorPerJam.URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        RegisterAPIBacaSensorPerJam apiBacaSensorPerJam = retrofitPerJam.create(RegisterAPIBacaSensorPerJam.class);
        Call<List<GetDataSensorPerJam>> callDataSensorPerJam = apiBacaSensorPerJam.getNilaiSensorPerJam();
        callDataSensorPerJam.enqueue(new Callback<List<GetDataSensorPerJam>>() {
            @Override
            public void onResponse(Call<List<GetDataSensorPerJam>> call, Response<List<GetDataSensorPerJam>> response) {
                if (response.isSuccessful()) {
                    if (response.body().size() > 0) {
                        n = response.body().size();
                        for (int i = 0; i < n-1; i++){
                            datapH[i] = Float.parseFloat(String.valueOf(response.body().get(i).getPh_air()));
                            dataPpm[i] = Integer.parseInt(String.valueOf(response.body().get(i).getPpm_air()));
                            dataSuhu[i] = Integer.parseInt(String.valueOf(response.body().get(i).getSuhu_air()));

                        }
                        LineDataSetAir();
                    }
                }
            }

            @Override
            public void onFailure(Call<List<GetDataSensorPerJam>> call, Throwable t) {
                Toast.makeText(getContext(), "Periksa Koneksi Internet",Toast.LENGTH_LONG).show();

            }
        });
    }

    private void TampilDataSensor() {
        Retrofit retrofitSensor = new Retrofit.Builder()
                .baseUrl(RegisterAPIBacaSensor.URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        RegisterAPIBacaSensor apiBacaSensor = retrofitSensor.create(RegisterAPIBacaSensor.class);
        Call<GetDataSensor> callDataSensor = apiBacaSensor.getNilaiSensor();
        callDataSensor.enqueue(new Callback<GetDataSensor>(){

            @Override
            public void onResponse(Call<GetDataSensor> call, Response<GetDataSensor> response) {
                if(response.isSuccessful()){
                    nilai_pH = response.body().getPh_air();
                    nilai_Ppm = response.body().getPpm_air();
                    nilai_Suhu = response.body().getSuhu_air();
                    nilaiAliranAir = response.body().getAliran_air();
                    kondisipH = response.body().getKondisi_ph();
                    kondisippm = response.body().getKondisi_ppm();
                    kondisiSuhu = response.body().getKondisi_suhu();
                    nilaipH.setText(nilai_pH);
                    nilaiPpm.setText(nilai_Ppm);
                    nilaiSuhu.setText(nilai_Suhu);
                    if(nilaiAliranAir == 0){
                        pompaAir.setText("Hidup");
                    }else {
                        pompaAir.setText("Mati");
                    }

                    if(kondisipH == 1){
                        kondisi1 = " pH ";
                        kondisi = 1;
                    }else {
                        kondisi1="";
                        kondisi = 0;
                    }
                    if(kondisippm == 1){
                        kondisi2 = " PPM ";
                        kondisi = 1;
                    }else {
                        kondisi2="";
                        kondisi = 0;
                    }
                    if(kondisiSuhu == 1){
                        kondisi3 = " Suhu ";
                        kondisi = 1;
                    }else {
                        kondisi3="";
                        kondisi = 0;
                    }
                    if (kondisi != 0){
                        showNotif();
                    }

                }
            }

            @Override
            public void onFailure(Call<GetDataSensor> call, Throwable t) {
                Toast.makeText(getContext(), "Periksa Koneksi Internet",Toast.LENGTH_LONG).show();

            }
        });
    }

    private void showNotif() {
        String NOTIFICATION_CHANNEL_ID = "channel_androidnotif";
        Context context = this.getContext();
        NotificationManager notificationManager = (NotificationManager) context.getSystemService(NOTIFICATION_SERVICE);
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            String channelName = "Android Notif Channel";
            int importance = NotificationManager.IMPORTANCE_LOW;

            NotificationChannel mChannel = new NotificationChannel(NOTIFICATION_CHANNEL_ID, channelName, importance);
            notificationManager.createNotificationChannel(mChannel);
        }

        Intent mIntent = new Intent(getContext(), HomeFragment.class);
        Bundle bundle = new Bundle();
        bundle.putString("fromnotif", "notif");
        mIntent.putExtras(bundle);
        PendingIntent pendingIntent = PendingIntent.getActivity(getContext(), 0, mIntent, PendingIntent.FLAG_UPDATE_CURRENT);

        NotificationCompat.Builder builder = new NotificationCompat.Builder(getContext(),NOTIFICATION_CHANNEL_ID)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT);
        builder.setContentIntent(pendingIntent)
                .setSmallIcon(R.drawable.ic_warning_black_24dp)
                .setLargeIcon(BitmapFactory.decodeResource(this.getResources(), R.drawable.ic_warning_black_24dp))
                .setTicker("notif starting")
                .setAutoCancel(true)
                .setDefaults(Notification.DEFAULT_SOUND)
                .setContentTitle("PERINGATAN!")
                .setContentText("Kondisi" +kondisi1+kondisi2+kondisi3+ "air tidak normal");

        notificationManager = (NotificationManager) context.getSystemService(NOTIFICATION_SERVICE);
        notificationManager.notify(115, builder.build());
    }

    private void LineDataSetAir() {
        phValues.clear();
        ppmValues.clear();
        suhuValues.clear();
        phValues = new ArrayList<>();
        ppmValues = new ArrayList<>();
        suhuValues = new ArrayList<>();

        for (int i = 0; i < n-1; i++){
            phValues.add(new Entry(i,datapH[i]));
            ppmValues.add(new Entry(i,dataPpm[i]));
            suhuValues.add(new Entry(i,dataSuhu[i]));
        }

        LineDataSet lineDataSetpH = new LineDataSet(phValues, "Kondisi pH Air");
        LineDataSet lineDataSetppm = new LineDataSet(ppmValues, "Tingkat PPM Air");
        LineDataSet lineDataSetSuhu = new LineDataSet(suhuValues, "Kondisi Suhu Air");

        lineDataSetpH.setFillAlpha(110);
        lineDataSetppm.setFillAlpha(110);
        lineDataSetSuhu.setFillAlpha(110);

        ArrayList<ILineDataSet> dataSetpH = new ArrayList<>();
        dataSetpH.add(lineDataSetpH);

        ArrayList<ILineDataSet> dataSetppm = new ArrayList<>();
        dataSetppm.add(lineDataSetppm);

        ArrayList<ILineDataSet> dataSetSuhu = new ArrayList<>();
        dataSetSuhu.add(lineDataSetSuhu);

        LineData datapH = new LineData(dataSetpH);
        chartpH.setData(datapH);
        chartpH.invalidate();

        LineData datappm = new LineData(dataSetppm);
        chartTds.setData(datappm);
        chartTds.invalidate();

        LineData dataSuhu = new LineData(dataSetSuhu);
        chartSuhu.setData(dataSuhu);
        chartSuhu.invalidate();
    }

    ArrayList<Entry> phValues = new ArrayList<>();
    ArrayList<Entry> ppmValues = new ArrayList<>();
    ArrayList<Entry> suhuValues = new ArrayList<>();
}
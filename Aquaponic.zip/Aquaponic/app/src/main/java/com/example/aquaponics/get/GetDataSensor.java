package com.example.aquaponics.get;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class GetDataSensor {
    @SerializedName("ph_air") @Expose String ph_air;
    @SerializedName("ppm_air") @Expose String ppm_air;
    @SerializedName("suhu_air") @Expose String suhu_air;
    @SerializedName("aliran_air") @Expose int aliran_air;
    @SerializedName("kondisi_ph") @Expose int kondisi_ph;
    @SerializedName("kondisi_ppm") @Expose int kondisi_ppm;
    @SerializedName("kondisi_suhu") @Expose int kondisi_suhu;

    public String getPh_air() {
        return ph_air;
    }

    public void setPh_air(String ph_air) {
        this.ph_air = ph_air;
    }

    public String getPpm_air() {
        return ppm_air;
    }

    public void setPpm_air(String ppm_air) {
        this.ppm_air = ppm_air;
    }

    public String getSuhu_air() {
        return suhu_air;
    }

    public void setSuhu_air(String suhu_air) {
        this.suhu_air = suhu_air;
    }

    public int getAliran_air() {
        return aliran_air;
    }

    public void setAliran_air(int aliran_air) {
        this.aliran_air = aliran_air;
    }

    public int getKondisi_ph() {
        return kondisi_ph;
    }

    public void setKondisi_ph(int kondisi_ph) {
        this.kondisi_ph = kondisi_ph;
    }

    public int getKondisi_ppm() {
        return kondisi_ppm;
    }

    public void setKondisi_ppm(int kondisi_ppm) {
        this.kondisi_ppm = kondisi_ppm;
    }

    public int getKondisi_suhu() {
        return kondisi_suhu;
    }

    public void setKondisi_suhu(int kondisi_suhu) {
        this.kondisi_suhu = kondisi_suhu;
    }
}

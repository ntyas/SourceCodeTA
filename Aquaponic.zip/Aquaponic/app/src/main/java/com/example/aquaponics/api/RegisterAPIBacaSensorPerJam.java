package com.example.aquaponics.api;

import com.example.aquaponics.get.GetDataSensorPerJam;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;

public interface RegisterAPIBacaSensorPerJam {
    String URL = "http://aquaponik.iotcenter.id/";
    @GET("BacasensorPerJam.php")
    Call<List<GetDataSensorPerJam>> getNilaiSensorPerJam();
}

package com.example.aquaponics;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.aquaponics.api.RegisterAPISetting;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import retrofit.RestAdapter;
import retrofit.RetrofitError;

public class SettingActivity extends AppCompatActivity {

    public static final String URL = "http://aquaponik.iotcenter.id/";
    EditText pHbawah, pHatas, ppmBawah, ppmAtas, suhuBawah, suhuAtas;
    int id = 1;
    int intensitas;
    Button btnSimpan;
    RadioGroup radioGroup;
    RadioButton radioButton;
    Toolbar toolbar;
    private ProgressDialog progress;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setting);

        pHbawah = findViewById(R.id.phbawah);
        pHatas = findViewById(R.id.pHatas);
        ppmAtas = findViewById(R.id.tdsatas);
        ppmBawah = findViewById(R.id.tdsbawah);
        suhuBawah = findViewById(R.id.suhubawah);
        suhuAtas = findViewById(R.id.suhuatas);
        btnSimpan = findViewById(R.id.simpan);
        radioGroup = findViewById(R.id.rg);

        toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle("Setting Nilai Awal");
        setSupportActionBar(toolbar);

        toolbar.setNavigationIcon(R.drawable.ic_arrow_back_black_24dp);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });


        btnSimpan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int selectedId = radioGroup.getCheckedRadioButtonId();
                radioButton = (RadioButton)findViewById(selectedId);
                progress = new ProgressDialog(SettingActivity.this);
                progress.setCancelable(false);
                progress.setMessage("Menyimpan ...");
                progress.show();
                RestAdapter adapter = new RestAdapter.Builder()
                        .setEndpoint(URL)
                        .build();
                RegisterAPISetting api = adapter.create(RegisterAPISetting.class);
                api.insertNilai(id,pHbawah.getText().toString(),
                        pHatas.getText().toString(),
                        ppmBawah.getText().toString(),
                        ppmAtas.getText().toString(),
                        suhuBawah.getText().toString(),
                        suhuAtas.getText().toString(),
                        radioButton.getText().toString(),
                        new retrofit.Callback<retrofit.client.Response>() {
                            @Override
                            public void success(retrofit.client.Response response, retrofit.client.Response response2) {
                                BufferedReader reader = null;
                                String output = "";
                                try {
                                    reader = new BufferedReader(new InputStreamReader(response.getBody().in()));
                                    output = reader.readLine();
                                    progress.dismiss();
                                    Toast.makeText(SettingActivity.this, "Berhasil menyimpan",Toast.LENGTH_LONG).show();
                                } catch (IOException e) {
                                    e.printStackTrace();
                                }
                            }

                            @Override
                            public void failure(RetrofitError error) {
                                Toast.makeText(SettingActivity.this, "Periksa Koneksi Internet",Toast.LENGTH_LONG).show();
                            }
                        });
            }
        });


    }
}

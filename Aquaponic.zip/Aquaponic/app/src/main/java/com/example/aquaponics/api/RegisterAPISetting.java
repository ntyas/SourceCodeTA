package com.example.aquaponics.api;

import retrofit.Callback;
import retrofit.client.Response;
import retrofit.http.Field;
import retrofit.http.FormUrlEncoded;
import retrofit.http.POST;

public interface RegisterAPISetting {
    @FormUrlEncoded
    @POST("/Setnilai.php")
    public void insertNilai(@Field("id_nilaiawal") int id,
                        @Field("ph_bawah") String pHbawah,
                        @Field("ph_atas") String pHatas,
                        @Field("ppm_bawah") String ppmBawah,
                        @Field("ppm_atas") String ppmAtas,
                        @Field("suhu_bawah") String suhuBawah,
                        @Field("suhu_atas") String suhuAtas,
                            @Field("intensitas_makan") String nilaiMakan,
                        Callback<Response> callback);

}
